// @winner-fed/cloud-utils -> webpack alias utils
declare module 'utils';

declare module '*.png';

declare module '*.gif';
