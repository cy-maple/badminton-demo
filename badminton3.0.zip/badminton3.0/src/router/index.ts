import { createRouter, createWebHashHistory } from 'vue-router';

export const routes = [
  {
    path: '/',
    component: () => import('../views/home/index.vue')
  },
  {
    path: '/home',
    name: 'Home',
    component: () => import('../views/home/index.vue')
  },
  {
    path: '/sign',
    name: 'Sign',
    component: () => import('../views/sign/index.vue')
  },
  {
    path: '/search',
    name: 'Search',
    component: () => import('../views/search/index.vue')
  },
  {
    path: '/about',
    name: 'About',
    component: () => import('../views/about/index.vue')
  }
];

const router = createRouter({
  history: createWebHashHistory(),
  routes
});

export function setupRouter(app) {
  app.use(router);
}

export default router;
