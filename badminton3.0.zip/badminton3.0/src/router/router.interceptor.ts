import router from './index';

router.beforeEach((to, from, next) => {
  next();
});
