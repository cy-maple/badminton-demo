import 'core-js/stable';
import 'regenerator-runtime/runtime';
import 'amfe-flexible';
import './assets/iconfont/iconfont.css'
import { createApp } from 'vue';
import App from './App.vue';
import router, { setupRouter } from './router';
import './router/router.interceptor';
import { setGlobalProperties } from '@/services';
import './icons';
import setupGlobalComponent from '@/components/global';
import { setApp } from './useApp';
import setupVendor from './vendor/wui';
import './assets/style/app.less';
import store from './store'
import Dialog from '@winner-fed/win-ui/es/dialog/index';
import Picker from '@winner-fed/win-ui/es/picker/index';
import Popup from '@winner-fed/win-ui/es/popup/index';
import '@winner-fed/win-ui/es/dialog/style/index';
import '@winner-fed/win-ui/es/picker/style/index';
import '@winner-fed/win-ui/es/popup/style/index';


async function bootstrap() {
  const app = createApp(App);
  app.use(store);
  app.use(Dialog);
  app.use(Picker);
  app.use(Popup);
  setupGlobalComponent(app);
  setGlobalProperties(app);
  setupVendor(app);
  setupRouter(app);

  // Mount when the route is ready
  // https://next.router.vuejs.org/api/#isready
  await router.isReady();
  app.mount('#badminton3060gg66o9mec', true);

  setApp(app);
}

bootstrap();

