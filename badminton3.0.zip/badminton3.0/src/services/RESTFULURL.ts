export default {
  octocat: 'octocat'
};
