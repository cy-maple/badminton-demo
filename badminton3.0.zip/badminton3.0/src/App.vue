<template>
  <div class="pages">
    <keep-alive v-if="$route.meta.keepAlive">
      <router-view />
    </keep-alive>
    <router-view v-if="!$route.meta.keepAlive" />
  </div>
  <div class="tabbar">
    <TabBar :tabList=tabList></TabBar>
  </div>
</template>
<script lang="ts">
  import { defineComponent } from 'vue';
  export default defineComponent({
    name: 'App',
  });
</script>
<script setup lang="ts">
  import TabBar from './components/TabBar/index.vue'
  const tabList = [{
      text: '报名',
      fontNagative: '&#xe603;',
      fontActive: '&#xe601;',
      url: '/home'
    }, {
      text: '签到',
      fontNagative: '&#xe605;',
      fontActive: '&#xe604;',
      url: '/sign'
    }, {
      text: '搜素',
      fontNagative: '&#xe606;',
      fontActive: '&#xe607;',
      url: '/search'
    }, {
      text: '关于',
      fontNagative: '&#xe600;',
      fontActive: '&#xe602;',
      url: '/about'
  }]
</script>
<style lang="less">
  body {
    margin: 0;
  }
  .pages {
    width: 100%;
    height: 90%;
  }
  .tabbar {
    position: absolute;
    width: 100%;
    height: 10%;
    bottom: 0;
  }
</style>
