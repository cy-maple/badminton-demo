import {createStore} from 'vuex'

export default createStore({
  state: {
    isSign: false,
    isSignIn: false,
    signIndex: -1
  },
  getters: {
    signTime(state) {
      let startTime = 16 + state.signIndex
      let endTime = 17 + state.signIndex
      return `${startTime}:30 - ${endTime}:30`
    }
  },
  mutations: {
    signConfirm(state, index) {
      state.isSign = true
      state.signIndex = index
    },
    signIn(state) {
      state.isSignIn = true
    },
    signCancel(state) {
      state.isSign = false
    }
  }
})