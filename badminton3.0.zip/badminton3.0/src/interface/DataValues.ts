/**
 *  定义接口类
 *  最佳实践 -> 接口名字一般建议 I 开头，便于别人阅读
 */

export interface DataValues {
  year: string;
  value: number;
}
