<script setup lang="ts">

</script>

<template>
  <div class="view">
<!-- 关于 -->
    <div class="view-about">
      <div class="about about-code">
        <div class="logo logo-code"></div>
        <div class="text text-code">编码:&nbsp;&nbsp;李文博</div>
      </div>
      <div class="about about-design">
        <div class="logo logo-design"></div>
        <div class="text text-design">设计:&nbsp;&nbsp;郑小平</div>
      </div>
    </div>
  </div>
</template>

<style lang="less" scoped src="./style.less"></style>
