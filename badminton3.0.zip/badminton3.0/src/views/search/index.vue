<script setup lang="ts">
  import { useStore } from 'vuex';
  import { ref } from 'vue'
  const store = useStore();
  const isShowSearchResult = ref(false);
  const isSearch = ref(false);
  const searchWindowStatus = ref(true);
  const actPlace = ref(1);
  const actPlaceList = [{text: '场地一', value: 1}, {text: '场地二', value: 2}, {text: '场地三', value: 3}, {text: '场地四', value: 4}];
  const actInfoList = [{
    userName: '张三',
    isSignIn: false
  },{
    userName: '李四',
    isSignIn: true
  }];
  const onConfirm = (value, index) => {
    isSearch.value = false
    isShowSearchResult.value = true
    actPlace.value = value.selectedIndexes[0] + 1
    console.log(value);
  };
  const onCancel = () => {
    isSearch.value = false
  };
// 查询结果返回
  const searchBack = () => {
    searchWindowStatus.value = false
    setTimeout(() => {
      searchWindowStatus.value = true
      isShowSearchResult.value = false
      actPlace.value = 1
    }, 500)
  };
// 取消报名
  const cancelSignUp = () => {
    store.commit('signCancel')
  };
// 查询
  const search = () => {
    isSearch.value = true
  };
</script>

<template>
  <div class="view">
<!-- 搜索 -->
    <div class="view-search">
      <div class="view-search_logo" :class="{'view-search_logo-active': store.state.isSign, 'view-search_logo-negative': !store.state.isSign}"></div>
      <div class="view-search_text" v-if="store.state.isSign">您已成功报名, 您的活动时间段为{{ store.getters.signTime }}</div>
      <div class="view-search_text" v-else>您还没有报名</div>
      <div class="btn btn-green" v-if="store.state.isSign&&!store.state.isSignIn" @click="cancelSignUp">取消报名</div>
      <div class="btn btn-blue" @click='search'>查询活动人员名单</div>
    </div>
<!-- 场地选择 -->      
    <win-popup v-model:show="isSearch" position="bottom" :style="{ height: '30%' }">
      <win-picker
        title="请选择场地"
        show-toolbar
        :visible-item-count="3"
        :columns="actPlaceList"
        @confirm="onConfirm"
        @cancel="onCancel"
      />
    </win-popup>
<!-- 查询结果 -->
    <div class="search-result" :class="{'search-result-clickIn': searchWindowStatus, 'search-result-clickOut': !searchWindowStatus}" v-if="isShowSearchResult">
      <div class="search-result-logo"></div>
      <div class="search-result-text">
        <div class="search-time">{{ store.getters.signTime }}</div>
        <div class="search-place">{{ actPlace }}号场地</div>
      </div>
      <!-- 查询结果列表 -->
      <div class="act-info">
        <div v-for="(item, index) in actInfoList" class="infoItem" :class="{'infoItem-active': item.isSignIn}">
          <div class="info-name">{{ item.userName }}</div>
          <div class="info-status" :class="{'info-status-active': item.isSignIn}">{{ item.isSignIn ? '已签到' : '未签到' }}</div>
        </div>
      </div>
      <div class="btn btn-green" @click="searchBack">返回</div>
    </div>
  </div>
</template>

<style lang="less" scoped src="./style.less"></style>
