<script setup lang="ts">
  import { useStore } from 'vuex';
  import { showConfirmDialog } from '@winner-fed/win-ui';
  const store = useStore();
  const signIn = () => {
    showConfirmDialog({
      message: '签到后不可取消报名, 请确认',
    }).then(() => {
      store.commit('signIn');
      console.log('hhh');
    }).catch(() => {
      // on cancel
    });
  }
</script>

<template>
  <div class="view">
<!-- 签到 -->
      <div class="sign-in">
        <div class="logo"></div>
        <div class="text" v-if="store.state.isSign">你的活动时间段为{{ store.getters.signTime }}, 一号场地</div>
        <div class="text" v-else>您还未报名, 请先报名</div>
        <div class="btn btn-green" @click="signIn" v-if="store.state.isSign&&!store.state.isSignIn">签到</div>
        <div class="btn btn-blue" v-if="store.state.isSign&&store.state.isSignIn">已签到</div>
      </div>
  </div>
</template>

<style lang="less" scoped src="./style.less"></style>
