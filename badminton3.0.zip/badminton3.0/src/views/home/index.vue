<script setup lang="ts">
  import {ref, onMounted} from 'vue';
  import Swiper from 'swiper';
  import 'swiper/dist/css/swiper.css';
  import {useStore} from 'vuex';
  const store = useStore();

  const signUpWindowStatus = ref(true);
  const isShowSearchResult = ref(false);
  const isShowSignUpResult = ref(false);
  const timeNow = ref('');
  const signUpIndexTemp = ref(0);
  interface swiperData {
    bacg: string,
    color: string,
    time: string
  }
  const swiperList: swiperData[] = [{
    bacg: require('../../assets/img/act1.png'),
    color: '#d9d17a',
    time: '16:30 - 17:30',
  },{
    bacg: require('../../assets/img/act2.png'),
    color: '#d37575',
    time: '17:30 - 18:30',
  },{
    bacg: require('../../assets/img/act3.png'),
    color: '#7fabd7',
    time: '18:30 - 19:30',
  },{
    bacg: require('../../assets/img/act4.png'),
    color: '#72bb4d',
    time: '19:30 - 20:30',
  },];
// 轮播图初始化
    const initSwiper = () => {
      let swiper = new Swiper('.swiper-container', {
        on: {
          slideChange: function(){
            signUpIndexTemp.value = this.activeIndex % 4;
          },
        },
        effect: 'coverflow',
        garbCursor: true,
        centeredSlides: true,
        slidesPerView: 'auto',
        coverflowEffect: {
          rotate: 15,
          stretch: 0,
          depth: 400,
          modifier: 2,
          slideShadows: false
        },
        loop: true
      })
    };
// 报名
    const signUp = () => {
      isShowSignUpResult.value = true
      store.state.isSign = true
      store.commit('signConfirm', signUpIndexTemp.value)
    };
// 报名结果返回
    const signUpBack = () => {
      signUpWindowStatus.value = false
      setTimeout(() => {
        signUpWindowStatus.value = true
        isShowSignUpResult.value = false
      }, 500)
    };
// 获取当前时间
    const getTime = () => {
      const dateNow = new Date()
      let year: number|string = dateNow.getFullYear()
      let month: number|string = dateNow.getMonth() + 1
      month = month < 10 ? '0' + month : month
      let date: number|string = dateNow.getDate()
      date = date < 10 ? '0' + date : date
      let day: number|string = dateNow.getDay()
      switch(day) {
        case 1:
          day = '一'
          break
        case 2:
          day = '二'
          break
        case 3:
          day = '三'
          break
        case 4:
          day = '四'
          break
        case 5:
          day = '五'
          break
      }
      timeNow.value = year + '-' + month + '-' + date + ' 星期' + day
    }
    
    onMounted(() => {
      initSwiper()
      getTime()
    })
</script>

<template>
  <div class="view">
<!-- 报名 -->
      <div class="view-sign-up">
        <div class="header">
          <div class="header-content">
            <div class="header-content_logo"></div>
            <div class="header-content_text">
              <div>员工号: 1213213</div>
              <div>手机号: 3123123</div>
            </div>
          </div>
        </div>
        <div class="sign-up-time">
          <div class="time-left">
            <i class="iconfont">&#xe60a;</i>
            <span>选择时间段</span>
          </div>
          <div class="time-right">{{ timeNow }}</div>
        </div>
        <div class="swiper-container">
          <div class="swiper-wrapper">
            <div class="swiper-slide" v-for="(item, index) in swiperList">
              <div class="sign-up-item">
                <div class="sign-up-item_bacg" :style="{backgroundImage: `url(${item.bacg})`, backgroundColor: item.color}"></div>
                <div class="sign-up-item_text">
                  <span>{{item.time}}</span>
                  <i class="iconfont" v-if="store.state.isSign&&store.state.signIndex === index">&#xe609;</i>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="btn btn-green" @click="signUp" v-if="!store.state.isSign">报名</div>
        <div class="btn btn-blue" v-else>已报名</div>
      </div>
<!-- 报名结果 -->
    <div class="sign-up-result" :class="{'sign-up-result-clickIn': signUpWindowStatus, 'sign-up-result-clickOut': !signUpWindowStatus}" v-if="isShowSignUpResult">
      <div class="sign-up-result-logo"></div>
      <div class="sign-up-result-text">你的报名已提交, 请等待报名结果通知</div>
      <div class="btn btn-green" @click="signUpBack">返回</div>
    </div>
  </div>
</template>

<style lang="less" scoped src="./style.less"></style>
