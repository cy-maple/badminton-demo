let app;
export function setApp(_app) {
  app = _app;
}

export function getApp() {
  return app;
}
