module.exports = {
  extends: ['@winner-fed/commitlint-config-win']
};
