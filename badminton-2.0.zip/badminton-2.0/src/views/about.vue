<template>
  <div class="view">
<!-- 关于 -->
    <div class="view-about">
      <div class="about about-code">
        <div class="logo logo-code"></div>
        <div class="text text-code">编码:&nbsp;&nbsp;李文博</div>
      </div>
      <div class="about about-design">
        <div class="logo logo-design"></div>
        <div class="text text-design">设计:&nbsp;&nbsp;郑小平</div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
      return {
        
      }
    }
}
</script>

<style lang="scss" scoped>
    @keyframes animationOfAboutFromLeft {
      0% {
        opacity: 0;
        transform: translateX(-200px);
      }
      90% {
        opacity: 1;
        transform: translateX(5px);
      }
      100% {
        transform: translateX(0);
      }
    }
    @keyframes animationOfAboutFromRight {
      0% {
        opacity: 0;
        transform: translateX(200px);
      }
      90% {
        opacity: 1;
        transform: translateX(-5px);
      }
      100% {
        transform: translateX(0);
      }
    }
    .view {
        position: relative;
        background-color: #fff;
        height: 100%;
          &-about {
            position: relative;
            height: 100%;
            background: url('../assets/image/bg-about.png') center no-repeat;
            background-size: contain;
            .about {
              position: absolute;
              display: flex;
              justify-content: center;
              align-items: center;                 
              &-code {
                bottom: 35%;
                left: 30%;
                animation: animationOfAboutFromLeft 1s;
              }
              &-design {
                bottom: 22%;
                left: 20%;
                animation: animationOfAboutFromRight 1s;
              }
              .logo {
                width: 50px;
                height: 50px;
                border-radius: 25px;
                margin-right: 15px;
                &-code {
                  background: url('../assets/image/face-liwb.png') center no-repeat;
                  background-size: contain;
                }
                &-design {
                  background: url('../assets/image/face-zhxp.png') center no-repeat;
                  background-size: contain;
                }
              }
            }
          }
    }
</style>