<template>
  <div class="view">
<!-- 报名 -->
      <div class="view-sign-up">
        <div class="header">
          <div class="header-content">
            <div class="header-content_logo"></div>
            <div class="header-content_text">
              <div>员工号: 1213213</div>
              <div>手机号: 3123123</div>
            </div>
          </div>
        </div>
        <div class="sign-up-time">
          <div class="time-left">
            <i class="iconfont">&#xe60a;</i>
            <span>选择时间段</span>
          </div>
          <div class="time-right">{{ timeNow }}</div>
        </div>
        <div class="swiper-container">
          <div class="swiper-wrapper">
            <div class="swiper-slide" v-for="(item, index) in swiperList">
              <div class="sign-up-item">
                <div class="sign-up-item_bacg" :style="{backgroundImage: `url(${item.bacg})`, backgroundColor: item.color}"></div>
                <div class="sign-up-item_text">
                  <span>{{item.time}}</span>
                  <i class="iconfont" v-if="$store.state.isSign&&$store.state.signIndex === index">&#xe609;</i>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="btn btn-green" @click="signUp" v-if="!$store.state.isSign">报名</div>
        <div class="btn btn-blue" v-else>已报名</div>
      </div>
<!-- 报名结果 -->
    <div class="sign-up-result" :class="{'sign-up-result-clickIn': signUpWindowStatus, 'sign-up-result-clickOut': !signUpWindowStatus}" v-if="isShowSignUpResult">
      <div class="sign-up-result-logo"></div>
      <div class="sign-up-result-text">你的报名已提交, 请等待报名结果通知</div>
      <div class="btn btn-green" @click="signUpBack">返回</div>
    </div>
  </div>
</template>

<script>
import Swiper from 'swiper'
import 'swiper/dist/css/swiper.css'
export default {
    data() {
      return {
        signUpWindowStatus: true,
        isShowSearchResult: false,
        isShowSignUpResult: false,
        timeNow: '',
        signUpIndexTemp: 0,
        swiperList: [{
          bacg: require('../assets/image/act1.png'),
          color: '#d9d17a',
          time: '16:30 - 17:30',
        },{
          bacg: require('../assets/image/act2.png'),
          color: '#d37575',
          time: '17:30 - 18:30',
        },{
          bacg: require('../assets/image/act3.png'),
          color: '#7fabd7',
          time: '18:30 - 19:30',
        },{
          bacg: require('../assets/image/act4.png'),
          color: '#72bb4d',
          time: '19:30 - 20:30',
        },]
      }
    }, 
    methods: {
// 轮播图初始化
      initSwiper() {
        let that = this;
        let swiper = new Swiper('.swiper-container', {
          on: {
            slideChange: function(){
              that.signUpIndexTemp = this.activeIndex % 4
            },
          },
          effect: 'coverflow',
          garbCursor: true,
          centeredSlides: true,
          slidesPerView: 'auto',
          coverflowEffect: {
            rotate: 15,
            stretch: 0,
            depth: 400,
            modifier: 2,
            slideShadows: false
          },
          loop: true
        })
      },
// 报名
      signUp() {
        this.$axios.post('/signUp', {
          actId: this.signUpIndexTemp
        }).then(res => {
          if(res.status === 200){
            this.isShowSignUpResult = true
            this.$store.state.isSign = true
            this.$store.commit('signConfirm', this.signUpIndexTemp)
          }
        })
      },
// 报名结果返回
      signUpBack() {
        this.signUpWindowStatus = false
        setTimeout(() => {
          this.signUpWindowStatus = true
          this.isShowSignUpResult = false
        }, 500)
      },
// 获取当前时间
      getTime() {
        const dateNow = new Date()
        let year = dateNow.getFullYear()
        let month = dateNow.getMonth() + 1
        month = month < 10 ? '0' + month : month
        let date = dateNow.getDate()
        date = date < 10 ? '0' + date : date
        let day = dateNow.getDay()
        switch(day) {
          case 1:
            day = '一'
            break
          case 2:
            day = '二'
            break
          case 3:
            day = '三'
            break
          case 4:
            day = '四'
            break
          case 5:
            day = '五'
            break
        }
        this.timeNow = year + '-' + month + '-' + date + ' 星期' + day
      }
    },
    mounted() {
      this.initSwiper()
      this.getTime()
    }
}
</script>

<style lang="scss" scoped>
    @keyframes animationOfPopUp {
      0% {
        transform: translateY(100vh);
      }
      100% {
        transform: translateY(0);
      }
    }
    @keyframes animationOfPopUpBack {
      0% {
        transform: translateY(0);
      }
      100% {
        transform: translateY(100vh);
      }
    }
    .view {
        position: relative;
        background-color: #fff;
        height: 100%;
        .btn {
            margin-top: 20px;
            margin-left: 10%;
            width: 80%;
            height: 50px;
            border-radius: 10px;
            font-size: 18px;
            font-weight: 400;
            line-height: 50px;
            color: #fff;
            &-green {
              background-color: #5dc08b;
            }
            &-blue {
              background-color: #49afd0;
            }
        }
        
        &-sign-up {
          height: 100%;
          background-color: #EBEEF5;
          .header {
            position: relative;
            width: 100%;
            height: 100px;
            border-radius: 0 0 50% 50%;
            background-color: #fff;
            &-content {
              display: flex;
              justify-content: center;
              align-items: center;
              position: absolute;
              left: 10%;
              top: 20%;
              &_logo {
                width: 100px;
                height: 50px;
                background: url('../assets/image/logo_hd.png') center no-repeat;
                background-size: contain;
              }
            }
          }
          .sign-up-time {
            display: flex;
            padding-top: 10%;
            position: relative;
            font-size: 14px;
            .time-left {
              position: absolute;
              left: 5%;
            }
            .time-right {
              position: absolute;
              right: 5%;
            }
          }
          .swiper-container {
            height: 50%;
            width: 100%;
            padding-top: 10%;
            .swiper-slide {
              width: 180px;
              border-radius: 10px;
              overflow: hidden;
              margin-left: 30px;
              margin-right: 40px;
              box-shadow: 0px 3px 8px rgba(0, 0, 0, 0.7);
              .sign-up-item {
                height: 100%;
                width: 180px;
                &_bacg {
                  height: 70%;
                  background: center no-repeat;
                  background-size: contain;
                }
                &_text {
                  height: 30%;
                  background-color: #fff;
                  padding-top: 25px;
                  font-size: 20px;
                  i {
                    padding-left: 10px;
                    color: #59a832;
                  }
                }
              }
            }
          }
        }

      .sign-up-result {
        position: absolute;
        width: 100%;
        height: 100vh;
        background-color: #fff;
        top: 0;
        left: 0;
        z-index: 99;
        &-clickIn {
          animation: animationOfPopUp 0.5s;
        }
        &-clickOut {
          animation: animationOfPopUpBack 0.5s forwards;
        }
        &-logo {
          margin-top: 10%;
          height: 40%;
          background: url('../assets/image/signUpSuccess.png') center no-repeat;
          background-size: contain;
        }
        &-text {
          margin-top: 5%;
        }
      }    
    }
</style>