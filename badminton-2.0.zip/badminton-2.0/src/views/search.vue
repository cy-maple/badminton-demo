<template>
  <div class="view">
<!-- 搜索 -->
      <div class="view-search">
        <div class="view-search_logo" :class="{'view-search_logo-active': $store.state.isSign, 'view-search_logo-negative': !$store.state.isSign}"></div>
        <div class="view-search_text" v-if="$store.state.isSign">您已成功报名, 您的活动时间段为{{ $store.getters.signTime }}</div>
        <div class="view-search_text" v-else>您还没有报名</div>
        <div class="btn btn-green" v-if="$store.state.isSign&&!$store.state.isSignIn" @click="cancelSignUp">取消报名</div>
        <div class="btn btn-blue" @click='search'>查询活动人员名单</div>
      </div>
<!-- 场地选择 -->      
      <van-popup v-model="isSearch" position="bottom" :style="{ height: '30%' }">
        <van-picker
          title="请选择场地"
          show-toolbar
          visible-item-count = 3
          :columns="actPlaceList"
          @confirm="onConfirm"
          @cancel="onCancel"
        />
      </van-popup>
<!-- 查询结果 -->
    <div class="search-result" :class="{'search-result-clickIn': searchWindowStatus, 'search-result-clickOut': !searchWindowStatus}" v-if="isShowSearchResult">
      <div class="search-result-logo"></div>
      <div class="search-result-text">
        <div class="search-time">{{ $store.getters.signTime }}</div>
        <div class="search-place">{{ this.actPlace }}号场地</div>
      </div>
      <!-- 查询结果列表 -->
      <div class="act-info">
        <div v-for="(item, index) in actInfoList" class="infoItem" :class="{'infoItem-active': item.isSignIn}">
          <div class="info-name">{{ item.userName }}</div>
          <div class="info-status" :class="{'info-status-active': item.isSignIn}">{{ item.isSignIn ? '已签到' : '未签到' }}</div>
        </div>
      </div>
      <div class="btn btn-green" @click="searchBack">返回</div>
    </div>
  </div>
</template>

<script>
export default {
    data() {
      return {
        isShowSearchResult: false,
        isSearch: false,
        searchWindowStatus: true,
        actPlace: 1,
        actPlaceList: ['场地一', '场地二', '场地三', '场地四'],
        actInfoList: [{
          userName: '张三',
          isSignIn: false
        },{
          userName: '李四',
          isSignIn: true
        }]
      }
    }, 
    methods: {
      onConfirm(value, index) {
        this.isSearch = false
        this.isShowSearchResult = true
        this.actPlace = index + 1
      },
      onCancel() {
        this.isSearch = false
      },
// 查询结果返回
      searchBack() {
        this.searchWindowStatus = false
        setTimeout(() => {
          this.searchWindowStatus = true
          this.isShowSearchResult = false
          this.actPlace = 1
        }, 500)
      },
// 取消报名
      cancelSignUp() {
        this.$store.commit('signCancel')
        this.signUpIndex = -1
      },
// 查询
      search() {
        this.isSearch = true
      },
// 查询确认
      searchConfirm() {
        this.isSearch = false
        this.isShowSearchResult = true
      },
    },
    computed: {
// 获取活动时间
      actTime() {
        let startTime = 16 + this.signUpIndex
        let endTime = 17 + this.signUpIndex
        return `${startTime}:30 - ${endTime}:30`
      }
    }
}
</script>

<style lang="scss" scoped>
    @keyframes animationOfPopUp {
      0% {
        transform: translateY(100vh);
      }
      100% {
        transform: translateY(0);
      }
    }
    @keyframes animationOfPopUpBack {
      0% {
        transform: translateY(0);
      }
      100% {
        transform: translateY(100vh);
      }
    }
    @keyframes animationOfSignIn {
      0% {
        opacity: 0;
        transform: scale(0.5);
      }
      20% {
        opacity: 1;
        transform: scale(1.1);
      }
      50% {
        transform: scale(0.9);
      }
      70% {
        transform: scale(1.05);
      }
      100% {
        transform: scale(1.0);
      }
    }
    .view {
        position: relative;
        background-color: #fff;
        height: 100%;
        .btn {
            margin-top: 20px;
            margin-left: 10%;
            width: 80%;
            height: 50px;
            border-radius: 10px;
            font-size: 18px;
            font-weight: 400;
            line-height: 50px;
            color: #fff;
            &-green {
              background-color: #5dc08b;
            }
            &-blue {
              background-color: #49afd0;
            }
        }
        
          &-search {
            height: 100%;
            &_logo {
              width: 90%;
              padding-left: 5%;
              position: relative;
              height: 50%;
              padding-top: 20%;
              animation: animationOfSignIn 1s;
              &-active {
                background: url('../assets/image/bg-search-act.png') center no-repeat;
                background-size: contain;
              }
              &-negative {
                background: url('../assets/image/bg-search-nag.png') center no-repeat;
                background-size: contain;
              }
            }
          }
         .search-result {
          position: absolute;
          width: 100%;
          height: 100vh;
          background-color: #fff;
          top: 0;
          left: 0;
          z-index: 99;
          &-clickIn {
            animation: animationOfPopUp 0.5s;
          }
          &-clickOut {
            animation: animationOfPopUpBack 0.5s forwards;
          }
          &-logo {
            margin-top: 10%;
            height: 40%;
            background: url('../assets/image/searchResult.png') center no-repeat;
            background-size: contain;
          }
          &-text {
            display: flex;
            position: relative;
            margin-bottom: 50px;
            .search-time {
              position: absolute;
              left: 5%;
            }
            .search-place {
              position: absolute;
              right: 5%;
            }
          }
          .act-info {
            .infoItem {
              width: 90%;
              height: 40px;
              margin-left: 5%;
              margin-bottom: 5%;
              border: 2px solid #c0c0c0;
              border-radius: 5px;
              display: flex;
              line-height: 40px;
              text-align: center;
              overflow: hidden;
              .info-name {
                width: 70%
              }
              .info-status {
                width: 30%;
                background-color: #c0c0c0;
                &-active {
                  color: #fff;
                  background-color: #409EFF;
                }
              }
              &-active {
                border-color: #409EFF;
              }
            }
          }
        }
        
    }
</style>