<template>
  <div class="view">
<!-- 签到 -->
      <div class="sign-in">
        <div class="logo"></div>
        <div class="text" v-if="$store.state.isSign">你的活动时间段为{{ $store.getters.signTime }}, 一号场地</div>
        <div class="text" v-else>您还未报名, 请先报名</div>
        <div class="btn btn-green" @click="signIn" v-if="$store.state.isSign&&!$store.state.isSignIn">签到</div>
        <div class="btn btn-blue" v-if="$store.state.isSign&&$store.state.isSignIn">已签到</div>
      </div>
  </div>
</template>

<script>
export default {
    data() {
      return {

      }
    },
    methods: {
      signIn() {
        this.$dialog.confirm({
          message: '签到后不可取消报名, 请确认',
        }).then(() => {
            this.$store.commit('signIn') 
          }).catch(() => {
            // on cancel
          });
      }
    }
}
</script>

<style lang="scss" scoped>
    @keyframes animationOfSignIn {
      0% {
        opacity: 0;
        transform: scale(0.5);
      }
      20% {
        opacity: 1;
        transform: scale(1.1);
      }
      50% {
        transform: scale(0.9);
      }
      70% {
        transform: scale(1.05);
      }
      100% {
        transform: scale(1.0);
      }
    }
    .view {
        position: relative;
        background-color: #fff;
        height: 100%;
        .btn {
            margin-top: 20px;
            margin-left: 10%;
            width: 80%;
            height: 50px;
            border-radius: 10px;
            font-size: 18px;
            font-weight: 400;
            line-height: 50px;
            color: #fff;
            &-green {
              background-color: #5dc08b;
            }
            &-blue {
              background-color: #49afd0;
            }
        }
        .sign-in {
          width: 90%;
          margin-left: 5%;
          height: 100%;
          .logo {
            animation: animationOfSignIn 1s;
            padding-top: 20%;
            padding-bottom: 5%;
            margin-left: 10%;
            width: 80%;
            height: 45%;
            background: url('../assets/image/signIn.png') center no-repeat;
            background-size: contain;
          }
        }    
    }
</style>