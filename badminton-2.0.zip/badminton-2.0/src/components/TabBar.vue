<template>
  <div class="tabber">
    <ul>
      <li v-for='(item, index) in tabList' :class="{'active': ($route.path === '/' && item.url === '/home') || $route.path === item.url}"  @click="changeTab(item.url)">
        <i class="iconfont" v-if="$route.path !== item.url" v-html="item.fontNagative"></i>
        <i class="iconfont" v-else v-html="item.fontActive"></i>
        <div>{{ item.text }}</div>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  props: ['tabList'],
  methods: {
    changeTab(url) {
      if(url !== this.$route.path) {
        this.$router.push(`${url}`)
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.tabber {
    border-top: 1px solid #C0C4CC;
      width: 100%;
      height: 100%;
      background-color: #f8f8f8;
      ul {
        height: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
        list-style: none;
        padding: 0;
        margin: 0;
        text-align: center;
        li {
          color: #909399;
          flex: 1;
          i {
            font-size: 20px;
          }
          div {
            font-size: 12px;
          }
        }
        .active {
          color: #59a832;
        }
      }
  }
</style>