import Vue from 'vue'
import App from './App.vue'
import router from '../src/router'
import store from './store';
import { Picker, Dialog, Popup } from 'vant'
import axios from 'axios'
import './utils/mock.js'
import './assets/iconfont/iconfont.css'
import 'vant/lib/picker/style'
import 'vant/lib/dialog/style'
import 'vant/lib/popup/style'
Vue.prototype.$axios = axios

Vue.config.productionTip = false
Vue.use(Picker)
Vue.use(Dialog)
Vue.use(Popup)
new Vue({
  router,
  store,
  render: function (h) { return h(App) },
}).$mount('#app')
