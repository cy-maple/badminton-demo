<template>
  <div id="app">
    <div class="nav">
      <TabBar :tabList="tabList"></TabBar>
    </div>
    <div class="view-content">
      <router-view></router-view>
    </div>
  </div>
</template>

<script>
import TabBar from '@/components/TabBar.vue'
export default {
  name: 'App',
  data() {
    return {
      tabList: [{
          text: '报名',
          fontNagative: '&#xe603;',
          fontActive: '&#xe601;',
          url: '/home'
        }, {
          text: '签到',
          fontNagative: '&#xe605;',
          fontActive: '&#xe604;',
          url: '/sign'
        }, {
          text: '搜素',
          fontNagative: '&#xe606;',
          fontActive: '&#xe607;',
          url: '/search'
        }, {
          text: '关于',
          fontNagative: '&#xe600;',
          fontActive: '&#xe602;',
          url: '/about'
        }]
    }
  },
  components: {
    TabBar
  }
}
</script>

<style lang="scss">
  body {
    margin: 0;
  }
  #app {
    height: 100vh;
    font-family: Avenir, Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-align: center;
    color: #2c3e50;
  }
  .nav {
    width: 100%;
    height: 10%;
    position: absolute;
    bottom: 0;
  }
  .view-content {
    height: 90%;
  }
</style>
