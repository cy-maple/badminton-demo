import Mock from 'mockjs'
Mock.mock(/signUp/, 'post', () => {
  return {
    status: 200
  }
})